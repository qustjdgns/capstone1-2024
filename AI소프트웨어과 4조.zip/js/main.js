const userQueryInput = document.getElementById('userQuery');

let responseIndex = 0;

const askQuestionButton = document.getElementById('askQuestion');
const searchBox = document.getElementById('search');

const apiKey = 'AIzaSyAEMqIhdZz0qj4Uh-jmc36Z1CzjwxOsLQg'; 

askQuestionButton.addEventListener('click', function() {
  const userQuery = userQueryInput.value.trim();
  
  if (userQuery === "") {
    return;
  }

  sendQuestionToGeminiAPI(userQuery);
});

// 대화형 서비스를 위한 리퀘스트 데이터 초기화
let requestData = {
  "system_instruction": {
    "parts": { "text": "학과로 시작하는 질문이라면 그 학과에 맞는 자격증을 추천해줘\n\
       만약 사용자가 앞에 조건과 일치하지 않는 질문을 하거나, 자격증에 관련된 질문을 하지 않았을경우 자격증에 관련된 질문만 입력해달라고 출력해줘 \n\
       그게 아니라면 너는 자격증에 대한 정보를 최대한 자세하게 알려줘야해 그리고 모든 출력에는 html, css를 활용해서 가독성있게 꾸며줘, 너비는 마진,패딩을 포함해서 1000px를 넘지 않게 해줘 배경색은 주지마 또한 답에는 뭐로 출력했습니다 이런말 없이 답만 줘"}
  },
  "contents": []  // contents 배열을 올바르게 설정
};

function sendQuestionToGeminiAPI(query) {
  const apiUrl = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" + apiKey;

  // user role의 메시지를 requestData.contents 배열에 추가
  requestData.contents.push({
    'role': 'user',
    'parts': [
      {
        'text': query
      }
    ]
  });

  const question_box = `
    <div class="searchBox que">
      <h2>질문</h2>
      <div class="quesBox">
          ${query} 
      </div>
    </div>
  `;

  const tempDiv = document.createElement('div');
  tempDiv.innerHTML = question_box; // 문자열을 innerHTML로 삽입하여 DOM 요소로 변환

  // 변환된 DOM 요소에서 첫 번째 자식을 선택
  const questionElement = tempDiv.firstElementChild;
  // appendChild()를 사용하여 부모 요소에 자식 요소 추가
  searchBox.appendChild(questionElement);

  console.log("Request Data: ", JSON.stringify(requestData));

  // 요청 보내기
  fetch(apiUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(requestData)  // body에 JSON.stringify()로 데이터 전달
  })
  .then(response => {
    if (!response.ok) {
      throw new Error('서버 오류가 발생했습니다.');
    }
    return response.json();
  })
  .then(data => {
    displayAnswer(data);
  })
  .catch(error => {
      const response_box = `
        <div class="searchBox res">
        <h2>답변</h2>
        <div>
            ${error.message || "네트워크 오류가 발생했습니다."}
        </div>
      </div>
    `;

    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = response_box; // 문자열을 innerHTML로 삽입하여 DOM 요소로 변환

    // 변환된 DOM 요소에서 첫 번째 자식을 선택
    const ResponseElement = tempDiv.firstElementChild;
    // appendChild()를 사용하여 부모 요소에 자식 요소 추가
    searchBox.appendChild(ResponseElement);

  });
}

function displayAnswer(response) {
  // 응답에서 model의 답을 추출 
  let modelAnswer = response.candidates[0].content.parts[0].text;
  let response_box;

  // 모델의 답을 contents 배열에 추가
  requestData.contents.push({
    "role":"model",
    "parts": [
      {
        "text": modelAnswer
      }
    ]
  });

  // 이건 정상적으로 출력이 내가 원하는대로 왔을때
  if(modelAnswer.includes("```html") | modelAnswer.includes("```"))
  {
    const iframe_script = `
    <!-- iframe 내부 콘텐츠 --> 
    <script>
      window.onload = function() {
        sendSize()
      }
  
      function sendSize()
      {
            const height = document.documentElement.scrollHeight;
            const width = document.documentElement.scrollWidth;
            window.parent.postMessage({ height, width, key: 'iframe', index: ${responseIndex}}, '*');
      }
  
      const observer = new MutationObserver(() => {
          sendSize();
      });
  
      observer.observe(document.body, { attributes: true, childList: true, subtree: true });
  
      // 최초 호출
      window.addEventListener('load', sendSize);
    </script>
    `;

    modelAnswer = modelAnswer.replace('```html', '');
    modelAnswer = modelAnswer.replace('```', '');
    modelAnswer = modelAnswer.replace('</html>', iframe_script + '</html>');

    response_box = 
    `
      <div class="searchBox res">
      <h2>답변</h2>
      <iframe class="responseBox" style="margin:0 auto;">
  
      </iframe>
    </div>
    `;

    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = response_box; // 문자열을 innerHTML로 삽입하여 DOM 요소로 변환

    // 변환된 DOM 요소에서 첫 번째 자식을 선택
    const ResponseElement = tempDiv.firstElementChild;
    // appendChild()를 사용하여 부모 요소에 자식 요소 추가
    searchBox.appendChild(ResponseElement);

    // 응답을 화면에 출력
    const responseOutput = document.querySelectorAll('.responseBox');
    if (responseOutput.length > responseIndex) { responseOutput[responseIndex].srcdoc = modelAnswer; }
    responseIndex++;

  } else { // 출력이 정상적으로 안나왔을때 div로 출력되게 ㄱ 

    response_box = `
      <div class="searchBox res">
      <h2>답변</h2>
      <div>
          ${modelAnswer}
      </div>
    </div>
    `;

    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = response_box; // 문자열을 innerHTML로 삽입하여 DOM 요소로 변환

    // 변환된 DOM 요소에서 첫 번째 자식을 선택
    const ResponseElement = tempDiv.firstElementChild;
    // appendChild()를 사용하여 부모 요소에 자식 요소 추가
    searchBox.appendChild(ResponseElement);

  }
}

window.addEventListener('message', function(event) {
  // 보안 체크: 메시지가 iframe에서 왔는지 확인
  if(event.data && event.data.key === 'iframe')
  {
      const iframe = document.querySelectorAll('.responseBox');

      if (iframe.length > event.data.index)
      {
        if (event.data && event.data.height) {
          iframe[event.data.index].style.height = event.data.height + 'px';
        }
        if (event.data && event.data.width) {
            // iframe[event.data.index].style.width = event.data.width + 'px';
        }
      }
  }
});


const questionTarget = document.getElementById("footer"); // 관찰 대상
const fixedElement = document.getElementById("search2"); // 고정 요소

let observer; // IntersectionObserver 인스턴스

// Intersection Observer 초기화 및 설정
function initializeObserver() {
  if (observer) observer.disconnect(); // 기존 Observer 정리

  // Intersection Observer 콜백
  const observerCallback = (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        fixedElement.style.display = "flex";
      } else {
        fixedElement.style.display = "none";
      }
    });
  };

  // Intersection Observer 설정
  const observerOptions = {
    root: null, // 뷰포트를 기준으로 관찰
    threshold: 0.8, // 80% 이상 보이면 콜백 트리거
  };

  observer = new IntersectionObserver(observerCallback, observerOptions);
  observer.observe(questionTarget); // 대상 요소 관찰 시작
}

// 초기 Observer 설정
initializeObserver();

// MutationObserver로 DOM 변경 감지
const mutationObserver = new MutationObserver(() => {
  initializeObserver(); // DOM 변경 시 IntersectionObserver 재설정
});

// MutationObserver 설정
mutationObserver.observe(questionTarget, {
  childList: true, // 자식 추가/제거 감지
  subtree: true,   // 하위 노드 변경 감지
});


